#!/usr/bin/python
# coding: utf-8

import multiprocessing as mp
import os
import time
from fastFourierTransform import *
from molecule import *
from tool import *
from color import plotMat
import copy as cp

########################################
#MAIN

def main():

    parametres = gestion_parametres()

    '''
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    Modifier les paramètres pas de rotation, t, r
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    '''

    tmps1 = time.time()
    jobs = []
    alpha = 0

    # import des fichiers pdb
    
    # structure initale garde pour appliquer rotation sur nouveaux structure
    ligand = Molecule(parametres["Ligand"])

    recepteur = Molecule(parametres["Receptor"])


    ligand.translate(np.array([parametres["size"],parametres["size"],parametres["size"]]) / 2 - ligand.cdm)
    recepteur.translate(np.array([parametres["size"],parametres["size"],parametres["size"]]) / 2 - recepteur.cdm)
    ligand.calc_cdm()
    recepteur.calc_cdm()

    recepteur.init_fftgrid(parametres["rho"], parametres["size"])
    ligand.init_fftgrid(parametres["delta"], parametres["size"])
    # plotMat(ligand.fftGrid)
    #plotMat(recepteur.fftGrid)
    #exit()

    # calcul du taille de la grille en fonction de la taille du ligand et du récepteur
    # création de la grille pour le ligand et le récepteur
    # Une grille pour un recepteur
    # n grille du ligand autour du recepteur


    # exploration du domaine conformationnel autour du recepteur
    conjFFTrecepteur = conj_fourier(recepteur.fftGrid)

    # Création d'un tableau de Process pour calcul partagé
    while alpha <= 360:
        recv_end, send_end = mp.Pipe(False)
        thread = mp.Process(target=calculRotate_CreateGrid_FFT,
                            args=(alpha,
                                parametres["delta"],
                                parametres["dRot"],
                                parametres["size"],
                                conjFFTrecepteur,
                                ligand,
                                recepteur)
                            )
        # ajoute le thread à la liste de travail
        jobs.append(thread)
        # lancer le thread
        thread.start()
        # incrementation de alpha
        alpha += parametres["dRot"]
        break

    # attendre fin processus fils pour continuer execution du main
    for th in jobs:
        th.join()

    tmps2 = time.time()-tmps1
    print("Temps d'execution = %f" %tmps2)

def test_main():
    tmps1 = time.time()
    parametres["dRot"] = 60
    jobs = []
    alpha = 0

    parametres["rho"] = -5
    parametres["delta"] = 1

    # import des fichiers pdb
    ligand = Molecule("data/2bbm_B.pdb")

    # structure initale garde pour appliquer rotation sur nouveaux structure
    recepteur = Molecule("data/2bbm_A.pdb")
    
    # parametres["size"] = recepteur.dim + ligand.dim
    parametres["size"] = 128

    ligand.translate(np.array([parametres["size"],parametres["size"],parametres["size"]]) / 2 - ligand.cdm)
    recepteur.translate(np.array([parametres["size"],parametres["size"],parametres["size"]]) / 2 - recepteur.cdm)
    
    #ligand.coord = (np.array([parametres["size"],parametres["size"],parametres["size"]])/2) - (ligand.coord - ligand.cdm)
    #recepteur.coord = (np.array([parametres["size"],parametres["size"],parametres["size"]])/2) - (recepteur.coord - recepteur.cdm)

    ligand.calc_cdm()
    recepteur.calc_cdm()

    recepteur.init_fftgrid(parametres["rho"], parametres["size"])
    ligand.init_fftgrid(parametres["delta"], parametres["size"])

    #print("RECEPTEUR INIT")
    #printMat1(recepteur.fftGrid)
    #print("LIGAND INIT")
    #printMat1(ligand.fftGrid)

    #plotMat(recepteur.fftGrid)

    conjFFTrecepteur = conj_fourier(recepteur.fftGrid)
    #print("FFT RECEPTEUR")
    #printMat1(conjFFTrecepteur)

    ligandTmp = cp.deepcopy(ligand)

    # rotation du ligand autour du recepteur
    ligandTmp.rotate(ligand, 0, 0, 0)

    # recalcule de la nouvelle grille du ligand rotationne
    ligandTmp.init_fftgrid(parametres["delta"], parametres["size"])

    # calcul nouvel fft
    matCor = fast_fourier_transform(conjFFTrecepteur, ligandTmp.fftGrid, parametres["size"], plot=True)
    
    vectTranslation = search_max_corr(matCor)
    print(vectTranslation)

    ligandTmp.translate(vectTranslation)
    # print(ligandTmp.coord)

    # test ecriture fichier
    fileName = str(0) + "_" + str(0) + "_" + str(0) + ".pdb"
    path = 'results/' + fileName
    recepteur.write_pdb(path)
    ligandTmp.write_pdb(path)

    tmps2 = time.time()-tmps1
    print("Temps d'execution = %f" %tmps2)       


if __name__ == "__main__":
    main()
    # test_main()
